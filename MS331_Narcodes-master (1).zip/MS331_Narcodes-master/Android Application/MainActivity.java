package com.example.android.scrudium;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuInflater;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.squareup.picasso.Picasso;

import org.w3c.dom.Text;

public class MainActivity<toggle> extends AppCompatActivity {

    private RecyclerView mCrimeList;
    private DatabaseReference mDatabase;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
 Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);



        mDatabase = FirebaseDatabase.getInstance().getReference().child("criminal");
        mDatabase.keepSynced(true);
        mCrimeList = (RecyclerView)findViewById(R.id.myrecycleview);
        mCrimeList.setHasFixedSize(true);
        mCrimeList.setLayoutManager(new LinearLayoutManager(this));
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        layoutManager.setReverseLayout(true);
        layoutManager.setStackFromEnd(true);
        mCrimeList.setLayoutManager(layoutManager);

    }

    @Override
    protected void onStart() {
        super.onStart();
        FirebaseRecyclerAdapter<Crime, CrimeViewHolder>firebaseRecyclerAdapter = new FirebaseRecyclerAdapter<Crime, CrimeViewHolder>
                (Crime.class, R.layout.crime_row, CrimeViewHolder.class, mDatabase) {
            @Override
            protected void populateViewHolder(CrimeViewHolder viewHolder, Crime model, int position) {
                viewHolder.setName(model.getName());
                viewHolder.setAccuracy(model.getAccuracy());
                viewHolder.setTime(model.getTime());
                viewHolder.setLocation(model.getLocation());
                viewHolder.setActivity(model.getActivity());
                viewHolder.setAge(model.getAge());
                viewHolder.setGender(model.getGender());
                viewHolder.setEmotion(model.getEmotion());
        }
        };
        mCrimeList.setAdapter(firebaseRecyclerAdapter);
    }

    public static class CrimeViewHolder extends RecyclerView.ViewHolder {
        View mView;

        public CrimeViewHolder(View itemView) {
            super(itemView);
            mView = itemView;
        }

        public void setName(String name) {
            TextView post_name = (TextView) mView.findViewById(R.id.name1);
            post_name.setText(name);
        }

        public void setLocation(String location) {
            TextView post_name = (TextView) mView.findViewById(R.id.location1);
            post_name.setText(location);
        }

        public void setAccuracy(String accuracy) {
            TextView post_name = (TextView) mView.findViewById(R.id.acc1);
            post_name.setText(accuracy);
        }

        public void setTime(String time) {
            TextView post_name = (TextView) mView.findViewById(R.id.time1);
            post_name.setText(time);
        }

        public void setAge(String age) {
            TextView post_name = (TextView) mView.findViewById(R.id.age1);
            post_name.setText(age);
        }

        public void setEmotion(String emotion) {
            TextView post_name = (TextView) mView.findViewById(R.id.emotion1);
            post_name.setText(emotion);
        }

        public void setActivity(String activity) {
            TextView post_name = (TextView) mView.findViewById(R.id.activity1);
            post_name.setText(activity);
        }

        public void setGender(String gender) {
            TextView post_name = (TextView) mView.findViewById(R.id.gender1);
            post_name.setText(gender);
        }

    }
    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.signout, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {
            case R.id.signout:
                FirebaseAuth.getInstance().signOut();
                finish();
                startActivity(new Intent(this, LoginActivity.class));
                Toast.makeText(this, "Signed out", Toast.LENGTH_SHORT).show();
                break;
        }
        return true;
    }

  @SuppressWarnings("StatementWithEmptyBody")
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        if (id == R.id.nav_camera) {
            // Handle the camera action
        } else if (id == R.id.nav_gallery) {

        } else if (id == R.id.nav_slideshow) {

        } else if (id == R.id.nav_manage) {

        } else if (id == R.id.nav_share) {

        } else if (id == R.id.nav_send) {

        }

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
