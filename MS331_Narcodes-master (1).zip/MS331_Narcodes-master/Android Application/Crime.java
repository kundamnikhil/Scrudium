package com.example.android.scrudium;

public class Crime {
    private String accuracy;
    private String location;
    private String Name;
    private String time;
    private String Age;
    private String Gender;
    private String Activity;
    private String Emotion;

    public Crime(String accuracy, String location, String name, String time, String activity, String age, String gender, String emotion, String CImg) {
        this.accuracy = accuracy;
        this.location = location;
        this.Name = name;
        this.time = time;
        this.Activity = activity;
        this.Age = age;
        this.Gender = gender;
        this.Emotion = emotion;
    }


    public String getAccuracy() {
        return accuracy;
    }

    public void setAccuracy(String accuracy) {
        this.accuracy = accuracy;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        this.Name = name;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getActivity() {
        return Activity;
    }

    public void setActivity(String activity) {
        this.Activity = activity;
    }

    public String getAge() {
        return Age;
    }

    public void setAge(String age) { this.Age = age; }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        this.Gender = gender;
    }

    public String getEmotion() {
        return Emotion;
    }

    public void setEmotion(String emotion) {
        this.Emotion = emotion;
    }



public Crime(){

}
}
