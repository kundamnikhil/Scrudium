import tkinter as tk
import os
import time

window = tk.Tk()
window.title("Scrudium")
window.geometry("250x500")
def gotogui():
    os.system(
        "python try.py --model model/activity.model --label-bin model/lb.pickle --size 1 --detector face_detection_model --embedding-model openface_nn4.small2.v1.t7 --recognizer output/recognizer.pickle --le output/le.pickle")

def gotogui1():
    os.system(
        "python extract_embeddings.py --dataset dataset --embeddings output/embeddings.pickle  --detector face_detection_model --embedding-model openface_nn4.small2.v1.t7")
    os.system(
        "python train_model.py --embeddings output/embeddings.pickle --recognizer output/recognizer.pickle --le output/le.pickle")
def gotogui2():
    os.system(
        "python train.py --dataset newData --model model/activity.model --label-bin model/lb.pickle --epochs 20")
def gotogui3():
    os.system(
        "python try.py --model model/activity.model --label-bin model/lb.pickle --size 1 --detector face_detection_model --embedding-model openface_nn4.small2.v1.t7 --recognizer output/recognizer.pickle --le output/le.pickle --input manpreet.mp4 --output output/abc_128avg.avi")

def gotogui4():
    os.system(
        "python Demo_with_same.py --model model/activity.model --label-bin model/lb.pickle --size 1 --detector face_detection_model --embedding-model openface_nn4.small2.v1.t7 --recognizer output/recognizer.pickle --le output/le.pickle --output output/TestFin.avi")

def gotogui5():
    os.system(
        "python videoframe.py")
def gotogui6():
    os.system(
        "python face_train.py --cascade Haarcascades/haarcascade_frontalface_default.xml --output dataset/sahas")

labelt = tk.Label(window, text="WELCOME TO SCRUDIUM!!",font="Bold", bg='#ffd700', fg='#ffffff')
label3 = tk.Label(window, text="\n")
bt = tk.Button(window, text="Start Surveillance", bg='#0052cc', fg='#ffffff', command=gotogui)
label = tk.Label(window, text="\n")
bt6 = tk.Button(window, text="Get Face 360", bg='#0052cc', fg='#ffffff', command=gotogui6)
label6 = tk.Label(window, text="\n")
bt1 = tk.Button(window, text="Train the face", command=gotogui1, bg='#0052cc', fg='#ffffff')
label1 = tk.Label(window, text="\n")
bt2 = tk.Button(window, text="Train the video", command =gotogui2, bg='#0052cc', fg='#ffffff')
label2 = tk.Label(window, text="\n")
bt3 = tk.Button(window, text="Video input Surveillance ", command =gotogui3, bg='#0052cc', fg='#ffffff')
label4 = tk.Label(window, text="\n")
bt4 = tk.Button(window, text="Video to Frame Converter", command =gotogui5, bg='#0052cc', fg='#ffffff')
label5 = tk.Label(window, text="\n")
bt5 = tk.Button(window, text="Save and smoothen surveillance", command =gotogui4, bg='#0052cc', fg='#ffffff')
labelt.pack()
label3.pack()
bt.pack()
label.pack()
#label = tk.Label(window, text="train face").pack()
bt6.pack()
label6.pack()
bt1.pack()
label1.pack()
#label = tk.Label(window, text="QUIT").pack()
bt2.pack()
label2.pack()
bt3.pack()
label4.pack()
bt4.pack()
label5.pack()
bt5.pack()
window.mainloop()
