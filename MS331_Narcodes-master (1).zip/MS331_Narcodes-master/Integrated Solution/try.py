#python try.py --model model/activity.model --label-bin model/lb.pickle --size 1 --detector face_detection_model --embedding-model openface_nn4.small2.v1.t7 --recognizer output/recognizer.pickle --le output/le.pickle --output output/abc_128avg.avi


# import the necessary packages
from os import listdir
from os.path import isfile, join
import os
import cv2
from pathlib import Path
import cv2
import dlib
import tensorflow as tf
import sys
import numpy as np
import argparse
from contextlib import contextmanager
from wide_resnet import WideResNet
from keras.utils.data_utils import get_file
from keras.models import load_model
from keras.preprocessing.image import img_to_array
from tensorflow.keras.models import load_model
from collections import deque
import numpy as np
import argparse
import pickle
import cv2
from tensorflow.keras.models import load_model
from collections import deque
from imutils.video import VideoStream
from imutils.video import FPS
import numpy as np
import argparse
import imutils
import os
import time
import pickle
import cv2
import time
import datetime as datetime
import cv2
import os
from firebase import firebase
#from crypto.PublicKey import RSA
import googlemaps
from datetime import datetime
import tensorflow as tf
import tensorflow as tf


firebase = firebase.FirebaseApplication('https://scrudium-fecf2.firebaseio.com/')
#from crypto.PublicKey import RSA


gup_options =tf.compat.v1.GPUOptions(per_process_gpu_memory_fraction=0.30)
sess =tf.compat.v1.Session(config=tf.compat.v1.ConfigProto(gpu_options=gup_options))


# construct the argument parser and parse the arguments
ap = argparse.ArgumentParser()
ap.add_argument("-m", "--model", required=True,
	help="path to trained serialized model")
ap.add_argument("-l", "--label-bin", required=True,
	help="path to  label binarizer")
ap.add_argument("-i", "--input", type=str, default="",
	help="optional path to video file")
ap.add_argument("-s", "--size", type=int, default=128,
	help="size of queue for averaging")
ap.add_argument("-d", "--detector", required=True,
	help="path to OpenCV's deep learning face detector")
ap.add_argument("-me", "--embedding-model", required=True,
	help="path to OpenCV's deep learning face embedding model")
ap.add_argument("-r", "--recognizer", required=True,
	help="path to model trained to recognize faces")
ap.add_argument("-le", "--le", required=True,
	help="path to label encoder")
ap.add_argument("-c", "--confidence", type=float, default=0.5,
	help="minimum probability to filter weak detections")
args = vars(ap.parse_args())


classifier = load_model('emotion_little_vgg_3.h5')
face_classifier = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
pretrained_model = "weights.28-3.73.hdf5"
from os import listdir
from os.path import isfile, join
import os

modhash = 'fbe63257a054c1c5466cfd7bf14646d6'

emotion_classes = {0: 'Angry', 1: 'Fear', 2: 'Happy', 3: 'Neutral', 4: 'Sad', 5: 'Surprise'}




# load the trained model and label binarizer from disk
print("[INFO] loading model and label binarizer...")
model = load_model(args["model"])
lb = pickle.loads(open(args["label_bin"], "rb").read())

#face rec model
protoPath = os.path.sep.join([args["detector"], "deploy.prototxt"])
modelPath = os.path.sep.join([args["detector"],
	"res10_300x300_ssd_iter_140000.caffemodel"])
detector = cv2.dnn.readNetFromCaffe(protoPath, modelPath)

# load our serialized face embedding model from disk
print("[INFO] loading face recognizer...")
embedder = cv2.dnn.readNetFromTorch(args["embedding_model"])

# load the actual face recognition model along with the label encoder
recognizer = pickle.loads(open(args["recognizer"], "rb").read())
le = pickle.loads(open(args["le"], "rb").read())

#fps=FPS.start()

# initialize the image mean for mean subtraction along with the
# predictions queue
mean = np.array([123.68, 116.779, 103.939][::1], dtype="float32")
Q = deque(maxlen=args["size"])


def draw_label(image, point, label, font=cv2.FONT_HERSHEY_SIMPLEX,
               font_scale=0.8, thickness=1):
    size = cv2.getTextSize(label, font, font_scale, thickness)[0]
    x, y = point
    cv2.rectangle(image, (x, y - size[1]), (x + size[0], y), (255, 0, 0), cv2.FILLED)
    cv2.putText(image, label, point, font, font_scale, (255, 255, 255), thickness, lineType=cv2.LINE_AA)


# Define our model parameters
depth = 16
k = 8
weight_file = None
margin = 0.4
image_dir = None

# Get our weight file
if not weight_file:
    weight_file = get_file("weights.28-3.73.hdf5", pretrained_model, cache_subdir="pretrained_models",
                           file_hash=modhash, cache_dir=Path(sys.argv[0]).resolve().parent)
# load model and weights
img_size = 64
modele = WideResNet(img_size, depth=depth, k=k)()
modele.load_weights(weight_file)

detectore = dlib.get_frontal_face_detector()



# initialize the video stream, pointer to output video file, and
# frame dimensions
vs = cv2.VideoCapture(args["input"] if args["input"] else 0)
(W, H) = (None, None)



# loop over frames from the video file stream
while True:
	# read the next frame from the file
	(grabbed, frame) = vs.read()

	# if the frame was not grabbed, then we have reached the end
	# of the stream
	if not grabbed:
		break

	# if the frame dimensions are empty, grab them
	if W is None or H is None:
		(H, W) = frame.shape[:2]

	# clone the output frame, then convert it from BGR to RGB
	# ordering, resize the frame to a fixed 224x224, and then
	# perform mean subtraction
	input_img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
	img_h, img_w, _ = np.shape(input_img)
	detected = detectore(frame, 1)
	faces = np.empty((len(detected), img_size, img_size, 3))

	frame1 = frame
	output = frame.copy()
	frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
	frame = cv2.resize(frame, (224, 224)).astype("float32")
	frame -= mean


	# make predictions on the frame and then update the predictions
	# queue
	preds1 = model.predict(np.expand_dims(frame, axis=0))[0]
	Q.append(preds1)


	# perform prediction averaging over the current history of
	# previous predictions
	results = np.array(Q).mean(axis=0)
	i = np.argmax(results)
	label = lb.classes_[i]

	text2 = "activity: {}".format(label)

	cv2.putText(output, text2, (35, 50), cv2.FONT_HERSHEY_SIMPLEX,
				1.25, (0, 255, 0), 5)
	# draw the activity on the output frame


	# construct a blob from the image
	imageBlob = cv2.dnn.blobFromImage(
		cv2.resize(frame, (300, 300)), 1.0, (300, 300),
		(104.0, 177.0, 123.0), swapRB=False, crop=False)

	# apply OpenCV's deep learning-based face detector to localize
	# faces in the input image
	detector.setInput(imageBlob)
	detections = detector.forward()

	# loop over the detections
	for i in range(0, detections.shape[2]):
		# extract the confidence (i.e., probability) associated with
		# the prediction
		confidence = detections[0, 0, i, 2]
		#name ="undetected"
		p2 = 0
		# filter out weak detections
		if confidence > 0.15:
			# compute the (x, y)-coordinates of the bounding box for
			# the face
			box = detections[0, 0, i, 3:7] * np.array([W, H, W, H])
			(startX, startY, endX, endY) = box.astype("int")

			# extract the face ROI
			face = frame[startY:endY, startX:endX]
			(fH, fW) = face.shape[:2]

			# ensure the face width and height are sufficiently large
			if fW < 20 or fH < 20:
				continue

			# construct a blob for the face ROI, then pass the blob
			# through our face embedding model to obtain the 128-d
			# quantification of the face
			faceBlob = cv2.dnn.blobFromImage(face, 1.0 / 255,
				(96, 96), (0, 0, 0), swapRB=True, crop=False)
			embedder.setInput(faceBlob)
			vec = embedder.forward()

			# perform classification to recognize the face
			preds2 = recognizer.predict_proba(vec)[0]
			j = np.argmax(preds2)
			proba = preds2[j]
			name = le.classes_[j]
			p2 = proba * 100


			# draw the bounding box of the face along with the
			# associated probability
			text1 = "{}: {:.2f}%".format(name, p2)
			y = startY - 10 if startY - 10 > 10 else startY + 10


			cv2.putText(output, text1, (startX, y),
				cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 0, 255), 2)
			cv2.rectangle(output, (startX, startY), (endX, endY),
						  (0, 0, 255), 2)
			break
		else:
			name ="undetected"



	preprocessed_faces_emo = []
	if len(detected) > 0:
		for i, d in enumerate(detected):
			x1, y1, x2, y2, w, h = d.left(), d.top(), d.right() + 1, d.bottom() + 1, d.width(), d.height()
			xw1 = max(int(x1 - margin * w), 0)
			yw1 = max(int(y1 - margin * h), 0)
			xw2 = min(int(x2 + margin * w), img_w - 1)
			yw2 = min(int(y2 + margin * h), img_h - 1)
			cv2.rectangle(frame1, (x1, y1), (x2, y2), (255, 0, 0), 2)
			# cv2.rectangle(img, (xw1, yw1), (xw2, yw2), (255, 0, 0), 2)
			faces[i, :, :, :] = cv2.resize(frame1[yw1:yw2 + 1, xw1:xw2 + 1, :], (img_size, img_size))
			face = frame1[yw1:yw2 + 1, xw1:xw2 + 1, :]
			face_gray_emo = cv2.cvtColor(face, cv2.COLOR_BGR2GRAY)
			face_gray_emo = cv2.resize(face_gray_emo, (48, 48), interpolation=cv2.INTER_AREA)
			face_gray_emo = face_gray_emo.astype("float") / 255.0
			face_gray_emo = img_to_array(face_gray_emo)
			face_gray_emo = np.expand_dims(face_gray_emo, axis=0)
			preprocessed_faces_emo.append(face_gray_emo)

		# make a prediction for Age and Gender
		results = modele.predict(np.array(faces))
		predicted_genders = results[0]
		ages = np.arange(0, 101).reshape(101, 1)
		predicted_ages = results[1].dot(ages).flatten()

		# make a prediction for Emotion
		emo_labels = []
		for i, d in enumerate(detected):
			preds = classifier.predict(preprocessed_faces_emo[i])[0]
			emo_labels.append(emotion_classes[preds.argmax()])

		# draw results
		for i, d in enumerate(detected):
			label = "{}-{}, {}, {}".format(int(predicted_ages[i]-10),int(predicted_ages[i]+5),
										"F" if predicted_genders[i][0] > 0.3 else "M", emo_labels[i])
			draw_label(output, (d.left(), d.top()), label)
			if ((text2 != "activity: normal") or (name != "undetected" and p2 > 40)):
				now = datetime.now()
				current_time = now.strftime("%H:%M:%S")
				result = firebase.post('/criminal',{'Name':name, 'Activity': text2, 'Age': str(int(predicted_ages[i])-10)+"-"+str(int(predicted_ages[i])+5), 'Gender':"F" if predicted_genders[i][0] > 0.4 else "M", 'Emotion':emo_labels[i], 'location': 'bolarum', 'accuracy': str(int(p2)), 'time': current_time})

				print(result)



	cv2.imshow("Output", output)
	key = cv2.waitKey(1) & 0xFF
	# if the `q` key was pressed, break from the loop
	if key == ord("q"):
		break

vs.release()