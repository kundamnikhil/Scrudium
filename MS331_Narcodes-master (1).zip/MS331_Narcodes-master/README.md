# MS331_Narcodes
In order to download the pre-trained model for emotion classification please download file from the given link
https://drive.google.com/drive/folders/1_E8y3nw_imusM-j49XJqKfzPaIokvwf7?usp=sharing
